package Messenger;

import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class Udpserv extends Thread implements Runnable {
	private Pseudonyme p;
	
	public Udpserv(Pseudonyme pseudo) {
		this.p = pseudo;
		this.start();
	}
	
	public void run() {
		try {
			DatagramSocket serverSocketUDP = new DatagramSocket(4445);
    		byte[] buffer = new byte[65536];
    		DatagramPacket incomingUDP = new DatagramPacket(buffer, buffer.length);
			while(true) {
		        serverSocketUDP.receive(incomingUDP);
        		String receivedData = new String(incomingUDP.getData());
        		if(this.p.isin(receivedData) == 1) {
        			this.p.addPseudo(receivedData);
        		}
			}
		} catch (Exception e) {
		      e.printStackTrace();
		}
	}

}

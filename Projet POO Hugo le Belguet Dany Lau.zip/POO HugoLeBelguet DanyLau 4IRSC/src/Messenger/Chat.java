package Messenger;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Iterator;


public class Chat {
	
	private ArrayList<String> users1;
	private ArrayList<String> users2;
	private ArrayList<String> users3;
	private ArrayList<String> users4;
	private ArrayList<String> users5;
	private ArrayList<String> users6;
	private ArrayList<String> users7;
	private ArrayList<String> users8;
	private ArrayList<String> users9;
	private ArrayList<String> users10;
	private ArrayList<ArrayList> users;
	private int i = 0;
	
	public Chat() {
		users1 = new ArrayList<String>();
		users2 = new ArrayList<String>();
		users3 = new ArrayList<String>();
		users4 = new ArrayList<String>();
		users5 = new ArrayList<String>();
		users6 = new ArrayList<String>();
		users7 = new ArrayList<String>();
		users8 = new ArrayList<String>();
		users9 = new ArrayList<String>();
		users10 = new ArrayList<String>();
		users = new ArrayList<ArrayList>();
		users.add(users1);
		users.add(users2);
		users.add(users3);
		users.add(users4);
		users.add(users5);
		users.add(users6);
		users.add(users7);
		users.add(users8);
		users.add(users9);
		users.add(users10);
		users.get(0).add("unknown");
		users.get(1).add("unknown");
		users.get(2).add("unknown");
		users.get(3).add("unknown");
		users.get(4).add("unknown");
		users.get(5).add("unknown");
		users.get(6).add("unknown");
		users.get(7).add("unknown");
		users.get(8).add("unknown");
		users.get(9).add("unknown");
	}
	
	
	public void addmessages(String message) {
		String[] inc = message.split(":");
		if(checkusers(message) == 1) {
			users.get(i).remove(0);
			users.get(i).add(inc[0]);
			users.get(i).add(message);
			i = i+1;
		}	
	}
	
	public int checkusers(String message) {
		Iterator<ArrayList> itr = users.iterator();
		while (itr.hasNext()) {
			if (messagemanager(message, itr.next()) == 1) {
				continue;
			}
			else {
				return 0;
			}
        }
		return 1;
	}
	
	public int messagemanager(String message, ArrayList<String> t) {
		String[] inc = message.split(":");
		if(t.get(0).equals(inc[0])) {
			t.add(message);
			return 0;
		}
		else {
			return 1;
		}
		
	}
	
	public String getmessages(int i) {
		String mess = new String();
		
		Iterator<String> itr = users.get(i).iterator();
		itr.next();
        while (itr.hasNext()) {
            mess += itr.next();
            mess += "\n";
        }
        return mess;
	}
	
	public void addmessageslocal(String ptj, String message) {
		if(checkuserslocal(ptj,message) == 1) {
			users.get(i).remove(0);
			users.get(i).add(ptj);
			users.get(i).add(message);
			i = i+1;
		}
		else {
			
		}
	}
	public int checkuserslocal(String ptj,String message) {
		Iterator<ArrayList> itr = users.iterator();
		while (itr.hasNext()) {
			if (messagemanagerlocal(ptj, itr.next(),message) == 1) {
				continue;
			}
			else {
				return 0;
			}
        }
		return 1;
	}
	public int messagemanagerlocal(String ptj, ArrayList<String> t,String message) {
		String[] inc = ptj.split(":");
		if(t.get(0).equals(inc[0])) {
			t.add(message);
			return 0;
		}
		else {
			return 1;
		}
	}
}

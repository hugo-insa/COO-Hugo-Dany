package Messenger;

import javax.swing.*;

import java.awt.BorderLayout;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;

public class swingchat extends JFrame implements ActionListener {
	private JTextField tf;
	private JTextArea ta;
	private JButton send;
	private JButton reset;
	private JButton user;
	private JButton select;
	private Chat chat;
	private Pseudonyme pseudo;
    private int iduser = 0;
	
        public swingchat(Chat m, Pseudonyme p){
        	this.chat = m;
        	this.pseudo = p;
        	JFrame frame = new JFrame("Messenger");
            frame.setSize(1200,1000);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            JMenuBar mb = new JMenuBar();
            JMenu m1 = new JMenu("Option");
            mb.add(m1);
            JMenuItem m11= new JMenuItem("Username");
            m1.add(m11);
            JPanel panel= new JPanel();
            JLabel label= new JLabel("Enter Text");
            this.tf = new JTextField(50);
            reset = new JButton("Refresh");
            reset.addActionListener(this);
            send = new JButton("Send");
            send.addActionListener(this);
            
            user = new JButton("Users");
            user.addActionListener(this);
            select = new JButton("Select");
            select.addActionListener(this);
            panel.add(user);
            panel.add(select);
            
            this.tf.setSize(50, 50);
            panel.add(label);
            panel.add(tf);
            panel.add(send);
            panel.add(reset);
            ta = new JTextArea();
            ta.setSize(200, 200);
            frame.getContentPane().add(BorderLayout.SOUTH, panel);
            frame.getContentPane().add(BorderLayout.NORTH, mb);
            frame.getContentPane().add(BorderLayout.CENTER, ta);
            frame.setVisible(true);
            
            
        }
        
        public void setiduser(int i) {
        	iduser = i;
        }
        
        public int getiduser() {
        	return iduser;
        }
        
        public void actionPerformed(ActionEvent e) {
        	if(e.getSource() == send) {
        		envoie();
        	}
        	else if(e.getSource() == user) {
        		ta.setText(this.pseudo.listpseudo());
        	}
        	else if(e.getSource() == reset) {
        		ta.setText(this.chat.getmessages(getiduser()));
        	}
        	else {
        		if (tf.getText() != null) {
        			setiduser(Integer.parseInt(tf.getText()));
        		}
        	}
        }
        
        public void settext(String message) {
        	ta.setText(message);
        }
        
        public void envoie() {
    		try {
    			String adresse[] = this.pseudo.getPseudo(getiduser()).split("/");
    			InetAddress serveur = InetAddress.getByName(adresse[1]);
    		    Socket socket = new Socket(serveur, 7845);
    		    PrintStream out = new PrintStream(socket.getOutputStream());
    		    String message = this.pseudo.getMyPseudo() + ": " + tf.getText();
    		    this.chat.addmessageslocal(this.pseudo.pseudoforsend(getiduser()),message);
    		    ta.setText(this.chat.getmessages(getiduser()));
    		    tf.setText("");
    		    out.println(message);
    		    socket.close();
    		} catch (Exception e) {
    		    e.printStackTrace();
    		}
        }
}

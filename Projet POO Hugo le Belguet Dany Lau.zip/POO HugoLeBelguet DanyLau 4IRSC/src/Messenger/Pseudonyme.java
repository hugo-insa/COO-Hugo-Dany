package Messenger;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.*;

public class Pseudonyme {
	
	private ArrayList<String> Pseudo;
	private String MyPseudo;
	
	public Pseudonyme(String moi)  {
		this.MyPseudo = moi;
		this.Pseudo = new ArrayList<String>();
		Udpenvoie u = new Udpenvoie(this);
	}
	
	public String getPseudo(int i) {
		return this.Pseudo.get(i);
	}
	
	public void addPseudo(String ajout) {
		Pseudo.add(ajout);
	}
	
	public String getMyPseudo() {
		return this.MyPseudo;
	}
	
	public String myip() throws UnknownHostException {
		InetAddress ip = InetAddress.getLocalHost();
		String ret = ip.getHostAddress();
		return ret;
	}
	
	public String listpseudo() {
		String mess = new String();
			
		Iterator<String> itr = this.Pseudo.iterator();
			int n = 0;
			while (itr.hasNext()) {
				mess += n + " " + itr.next();
	            mess += "\n";
	            n = n+1;
	            }
			return mess;
		
	}
	
	public String pseudoforsend(int i) {
		String pseudo[] = this.Pseudo.get(i).split("/");
		return pseudo[0];
	}
	
	public int isin(String in) {
		Iterator<String> itr = this.Pseudo.iterator();
		while (itr.hasNext()) {
			if (in.equals(itr.next().toString())) {
				return 0;
			}
        }
		return 1;
	}
		
}

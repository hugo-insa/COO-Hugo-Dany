package Messenger;
import javax.swing.*;

import java.awt.BorderLayout;
import java.awt.event.*;
import java.util.ArrayList;

public class swingconnection extends JFrame implements ActionListener {
	
	private JButton bt;
	private JTextField idt;
	private ArrayList<String> idconnexion;
	private JPasswordField mdpt;

		   public swingconnection(){
		     JFrame frame = new JFrame("Connection");
		     frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		     frame.setSize(400,200);
		     
		     JLabel id = new JLabel("Identifiant");
		     idt = new JTextField(15);
		     JPanel pid = new JPanel();
		     pid.add(id);
		     pid.add(idt);
		     
		     JLabel mdp = new JLabel("Mot de passe");
		     mdpt = new JPasswordField(15);
		     JPanel pmdp = new JPanel();
		     pmdp.add(mdp);
		     pmdp.add(mdpt);
		     
		     bt = new JButton("Se connecter");     
		     bt.addActionListener(this);
		     
		     JPanel panneau = new JPanel();
		     panneau.add(bt);
		     
		     frame.getContentPane().add(BorderLayout.NORTH,pid);
		     frame.getContentPane().add(BorderLayout.CENTER,pmdp);
		     frame.getContentPane().add(BorderLayout.SOUTH,panneau);
		     frame.setVisible(true);
		     
		     
		     users();
		   }
		   
		public void users(){
			idconnexion = new ArrayList<String>();
			idconnexion.add("user1");
			idconnexion.add("user1");
			idconnexion.add("hugo");
			idconnexion.add("hugo");
			idconnexion.add("danny");
			idconnexion.add("danny");
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource() == bt) {
				for(int i=0;i<5;i++) {
					if(idt.getText().equals(idconnexion.get(i)) && mdpt.getText().equals(idconnexion.get(i+1))) {
						swingpseudo s = new swingpseudo();
        			}
				}
        	}
        	else {
        		idt.setText("Wrong credentials");
        	}
			
		}
}
	

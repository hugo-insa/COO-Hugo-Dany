package Messenger;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class Udpenvoie extends Thread implements Runnable {
	
	private Pseudonyme pseudo;
	private String envoie;
	private DatagramSocket socket;
    private InetAddress address;
    private byte[] buf;
	
	public Udpenvoie(Pseudonyme p) {
		this.pseudo = p;
		this.start();
	}
	
	public void run() {
		try {
    		envoie = this.pseudo.getMyPseudo() +  "/" + this.pseudo.myip();
    		socket = new DatagramSocket();
            address = InetAddress.getByName("255.255.255.255");
            while(true) {
            	buf = envoie.getBytes();
                DatagramPacket packet = new DatagramPacket(buf, buf.length, address, 4446);
                socket.send(packet);
                Thread.sleep(5000);
            }
    	}catch(Exception e){
    		e.printStackTrace();
    	}
	}

}

package Messenger;

import java.net.UnknownHostException;

public class Main {
	
	public static void main(String []args) throws UnknownHostException{
		swingconnection t = new swingconnection();
     }

}

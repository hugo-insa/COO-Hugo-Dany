package Messenger;

public class ChatNotify {
	
	private swingchat fen;
	private Chat chat;
	
	public ChatNotify(swingchat f, Chat c) {
		this.chat = c;
		this.fen = f;
	}
	
	public void notifyfen() {
		this.fen.settext(this.chat.getmessages(this.fen.getiduser()));
	}
}

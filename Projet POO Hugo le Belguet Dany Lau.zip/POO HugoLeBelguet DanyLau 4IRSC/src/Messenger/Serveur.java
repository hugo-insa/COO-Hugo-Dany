package Messenger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;



public class Serveur{
	
	private ServerSocket serverSocket;
    private Socket clientSocket;
    private swingchat i;
    private Chat m;
    private Pseudonyme p;
    private ChatNotify a;
    
    private Thread tservtcp;
	
	public Serveur(String pseudo) {
		p = new Pseudonyme(pseudo);
		m = new Chat();
		i = new swingchat(m, p);
		a = new ChatNotify(i,m);
		Udpserv u = new Udpserv(p);
		tservtcp = new Thread(( ) -> {
			try {
				ServerSocket serverSocket = new ServerSocket(7846);
				while(true) {
					clientSocket = serverSocket.accept();
					Tcpserv x = new Tcpserv(clientSocket,m,a);
				}
			} catch (Exception e) {
  		      e.printStackTrace();
  		    }
		});
	}
	
	public void serv() {
		tservtcp.start();
	}
}
